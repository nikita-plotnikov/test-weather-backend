"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = exports.respondJson = void 0;
const axios_1 = require("axios");
const secretsManager_1 = require("./secretsManager");
const redisUrl = process.env.REDIS_URL;
const API_KEY = process.env.WEATHERSTACK_API_KEY;
function respondJson(body, statusCode) {
    return {
        statusCode,
        body: JSON.stringify(body)
    };
}
exports.respondJson = respondJson;
async function handler(event) {
    const { city } = event.pathParameters;
    const secret = await secretsManager_1.SecretsManage.getSecret(process.env.SECRET_NAME, process.env.REGION);
    // const client = createClient({url: redisUrl});
    // const getAsync = promisify(client.get).bind(client);
    // const setAsync = promisify(client.set).bind(client);
    // const cachedCity = await getAsync(`${city}`);
    // if (cachedCity) {
    //     const formatCached: HttpResponseBody = JSON.parse(cachedCity);
    //     return respondJson(formatCached, 200);
    // }
    const endpoint = 'http://api.weatherstack.com/current';
    console.log('secret', secret);
    const { data } = await axios_1.default.get(endpoint, {
        params: { access_key: secret, query: city }
    });
    if ('error' in data) {
        return respondJson({ error: true }, 200);
    }
    console.log('data', data);
    const response = {
        city: data.location.name,
        temperature: data.current.temperature,
        textWeather: data.current.weather_descriptions,
        windSpeed: data.current.wind_speed,
        windDir: data.current.wind_dir,
        pressure: data.current.pressure,
        humidity: data.current.humidity,
    };
    // await setAsync(`${city}`, JSON.stringify(response))
    return respondJson(response, 200);
}
exports.handler = handler;
